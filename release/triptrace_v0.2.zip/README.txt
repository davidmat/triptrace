TripTrace
=========

PLEASE READ THIS FIRST!

=========

General info
------------

Triptrace is a Java desktop application, allowing you to `retrace` your trips.
Import your photos, place them on a map, and relive your trip!

Developed by: 
	David Mat
	Daan Willems

License:
	GPL

==========

Installation
------------

1.unzip triptrace.zip
2.run triptrace.jar
	YOU NEED TO HAVE A JVM INSTALLED FOR THIS TO WORK

Uninstall
---------

Remove the directory.

==========

User's manual
-------------

See the supplied file manual.pdf